
let viewCart = document.getElementById('viewcart-btn')
viewCart.addEventListener("click", function(){
    window.open("cart.html")
})
