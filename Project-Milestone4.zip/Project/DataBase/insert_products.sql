INSERT INTO Products (name, description, image_url, price, category_id) VALUES 
('Protein Powder - Strawberry', 'Premium quality protein powder for improved muscle recovery and performance.', 'Project/Assets/Product-Image.jpg', 60.00, 1),
('Multivitamins', 'Daily essential vitamins to support overall health.', 'Project/Assets/vitamins.jpg', 20.00, 2);