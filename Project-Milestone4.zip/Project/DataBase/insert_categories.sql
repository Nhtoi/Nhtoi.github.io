INSERT INTO Categories (name, priority_level) VALUES 
('Pre-Workout', 1), 
('Vitamins', 2), 
('Creatine', 3);
